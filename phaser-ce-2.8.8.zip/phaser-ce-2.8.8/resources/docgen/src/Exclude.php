<?php

/*
    PIXI.DisplayObject

    click
    mousedown
    mouseout
    mouseover
    mouseup
    mouseupoutside
    rightclick
    rightdown
    rightup
    rightupoutside
    setInteractive
    tap
    touchend
    touchendoutside
    touchstart
*/

?>